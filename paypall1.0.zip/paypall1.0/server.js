const express = require('express');
const path = require('path');

const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);

app.use(express.static(path.join(__dirname, 'public')));
app.set('views', path.join(__dirname, 'public'));
app.engine('html', require('ejs').renderFile);
app.set('view engine', 'html');

app.use('/', (req, res) => {
    res.render('index.html');
});


var contaCount = 0;
var conta01 = {};
var conta02 = {};



io.on('connection', socket =>{
    console.log(`Socket conectado: ${socket.id}`);
    contaCount = contaCount + 1;
    console.log(contaCount);


    if(contaCount == 3){
        conta01.username = socket.id;
        conta01.dinheiro = 5;
        socket.emit('conta', conta01);
        console.log(conta01);
    }

    if(contaCount == 4){
        conta02.username = socket.id;
        conta02.dinheiro = 2;
        socket.emit('conta', conta02);
        console.log(conta02);
    }


    socket.on('sendMoney', data =>{
        
        var qntd = Number(data.qntd);
        console.log(qntd);


        if(data.user == conta01.username && qntd <= conta01.dinheiro){
            //Somando o dinheiro para a conta 2
            conta02.dinheiro = conta02.dinheiro + qntd;

            //Tirando o dinheiro da conta 1
            conta01.dinheiro = conta01.dinheiro - qntd;

            socket.emit('subtrair', conta01.dinheiro);

            socket.broadcast.emit('somar02', conta02.username, conta02.dinheiro);

            console.log(conta01);
        }

        if(data.user == conta02.username && qntd <= conta02.dinheiro){
            //Somando o dinheiro para a conta 1
            conta01.dinheiro = conta01.dinheiro + qntd;

            //Tirando o dinheiro da conta 2
            conta02.dinheiro = conta02.dinheiro - qntd;

            socket.emit('subtrair', conta02.dinheiro);

            socket.broadcast.emit('somar01', conta01.username, conta01.dinheiro);

            console.log(conta02);
        }
    });
});

server.listen(3000);